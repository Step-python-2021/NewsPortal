from  config import mysql


class Article(object):

    @staticmethod
    def get_all_articles(self) -> list:
        pass
