# NewsPortal
demo news portal on python flask

Requires:

  - flask
  
  - flask-MySql
